"""
Fixtures compartilhadas. A fixture `db` garante que CADA teste roda contra
um SQLite temporário isolado (nunca o banco de produção), e restaura o
`db_path` original no final mesmo se o teste falhar.
"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

import config
import database


@pytest.fixture
def db():
    fd, path = tempfile.mkstemp(suffix=".sqlite3")
    os.close(fd)
    original_path = config.settings.db_path
    config.settings.db_path = path
    database.init_db()
    try:
        yield path
    finally:
        config.settings.db_path = original_path
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(path + suffix)
            except FileNotFoundError:
                pass
