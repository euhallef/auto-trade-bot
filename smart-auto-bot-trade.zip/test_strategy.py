import time

from database import insert_token, insert_trade, record_position_entry
from models import TokenCreated, Trade
from strategy import should_enter, should_exit, Action
from config import settings


def _mk_token(mint, creator, t0, initial_sol=1.0, cap=30.0):
    insert_token(TokenCreated(mint, mint, mint[:4], creator, t0, initial_sol, 900000000, cap))
    return TokenCreated(mint, mint, mint[:4], creator, t0, initial_sol, 900000000, cap)


def test_should_enter_skips_low_creator_commitment(db):
    token = TokenCreated("M1", "M1", "M1", "Creator1", time.time(), 0.01, 900000000, 30.0)
    decision = should_enter(token, [])
    assert decision.action == Action.SKIP


def test_should_enter_skips_bad_creator_reputation(db):
    t0 = time.time() - 10000
    for i in range(3):
        mint = f"BADHIST{i}"
        _mk_token(mint, "CreatorBad", t0 + i * 100)
        insert_trade(Trade(f"{mint}-1", mint, "t1", "buy", 1.0, 100, 100, t0 + i * 100 + 1))
        insert_trade(Trade(f"{mint}-2", mint, "t1", "sell", 0.05, 100, 3, t0 + i * 100 + 50))

    new_token = TokenCreated("BADNEW", "BADNEW", "BDN", "CreatorBad", time.time(), 1.0, 900000000, 30.0)
    decision = should_enter(new_token, [])
    assert decision.action == Action.SKIP


def test_should_enter_buys_speculatively_without_history(db):
    token = TokenCreated("NEWCR", "NEWCR", "NCR", "CreatorNovo", time.time(), 1.0, 900000000, 30.0)
    decision = should_enter(token, [])
    assert decision.action == Action.BUY
    assert decision.confidence < 0.5  # especulativo, confiança baixa


def test_should_exit_stop_loss(db):
    t0 = time.time() - 100
    _mk_token("MSTOP", "Creator1", t0)
    insert_trade(Trade("s1", "MSTOP", "t1", "buy", 0.1, 100, 30 * (1 + settings.stop_loss_pct / 100) - 0.01, t0 + 1))
    pos_id = record_position_entry("MSTOP", 30.0, 0.05, dry_run=True)

    decision = should_exit("MSTOP", 30.0, t0, [], hit_levels="")
    assert decision.action == Action.SELL
    assert "Stop loss" in decision.reason


def test_should_exit_hard_take_profit(db):
    t0 = time.time() - 100
    _mk_token("MTP", "Creator1", t0)
    insert_trade(Trade("s1", "MTP", "t1", "buy", 5.0, 100, 30 * (1 + settings.hard_take_profit_pct / 100) + 1, t0 + 1))

    decision = should_exit("MTP", 30.0, t0, [], hit_levels="")
    assert decision.action == Action.SELL
    assert "Take profit" in decision.reason


def test_should_exit_partial_level_triggers_once(db):
    t0 = time.time() - 100
    _mk_token("MPART", "Creator1", t0)
    insert_trade(Trade("s1", "MPART", "t1", "buy", 0.5, 100, 60.0, t0 + 1))  # +100%

    first_level = settings.partial_take_profit_levels[0][0]
    decision = should_exit("MPART", 30.0, t0, [], hit_levels="")
    assert decision.action == Action.SELL_PARTIAL
    assert decision.level_key == f"L{first_level:.0f}"

    # já tendo batido esse nível, não deve disparar de novo
    decision2 = should_exit("MPART", 30.0, t0, [], hit_levels=decision.level_key)
    assert decision2.level_key != decision.level_key


def test_should_exit_holds_with_no_trigger(db):
    t0 = time.time() - 100
    _mk_token("MHOLD", "Creator1", t0)
    insert_trade(Trade("s1", "MHOLD", "t1", "buy", 0.1, 100, 32.0, t0 + 1))  # +6.7%, nada dispara

    decision = should_exit("MHOLD", 30.0, t0, [], hit_levels="")
    assert decision.action == Action.HOLD


def test_should_exit_no_trades_holds(db):
    decision = should_exit("NONEXISTENT", 30.0, time.time(), [], hit_levels="")
    assert decision.action == Action.HOLD
