"""
Motor de decisão. Combina os dois sinais analisados (reputação de
criador/holders + patamares estatísticos de risco) numa decisão concreta.

Isto NÃO é "IA prevendo o futuro" — é um sistema de regras + estatística
histórica. Trate como tal: um filtro que reduz apostas ruins óbvias,
não uma máquina de prever o próximo 100x.
"""
import time
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

from config import settings
from database import get_trades_for_mint
from models import ThresholdStat, TokenCreated
from wallet_analyzer import creator_reputation


class Action(Enum):
    SKIP = "skip"
    BUY = "buy"
    HOLD = "hold"
    SELL = "sell"           # encerra a posição por completo
    SELL_PARTIAL = "sell_partial"  # vende só uma fatia, posição continua aberta


@dataclass
class Decision:
    action: Action
    reason: str
    confidence: float  # 0.0 a 1.0 - NUNCA tratar como probabilidade de lucro real
    sell_pct: float = 100.0     # para SELL_PARTIAL: % do que RESTA na posição a vender agora
    level_key: Optional[str] = None  # identifica o patamar (evita disparar o mesmo nível 2x)


def should_enter(token: TokenCreated, backtest_stats: List[ThresholdStat]) -> Decision:
    """Decide se vale a pena entrar num token recém-criado."""

    if token.initial_sol_in_curve < settings.min_creator_sol_committed:
        return Decision(Action.SKIP, "Criador comprometeu pouco SOL na criação (sinal fraco de compromisso).", 0.0)

    rep = creator_reputation(token.creator)
    if rep < -0.3:
        return Decision(Action.SKIP, f"Criador tem histórico ruim (reputação={rep}).", 0.0)

    if rep == 0.0:
        return Decision(
            Action.BUY,
            "Sem histórico do criador — entrada especulativa de tamanho reduzido.",
            0.2,
        )

    confidence = min(0.6, 0.3 + rep * 0.3)
    return Decision(Action.BUY, f"Criador com reputação positiva ({rep}).", confidence)


def should_exit(
    mint: str,
    entry_market_cap_sol: float,
    entry_time: float,
    backtest_stats: List[ThresholdStat],
    hit_levels: str = "",
) -> Decision:
    """
    Decide se uma posição aberta deve ser encerrada (total ou parcialmente):
    1. Stop loss / take profit rígidos / timeout -> sempre saída TOTAL,
       têm prioridade sobre tudo (gestão de risco não é opcional).
    2. Saída parcial em camadas (settings.partial_take_profit_levels) ->
       realiza lucro aos poucos conforme o preço sobe, sem sair 100% de
       uma vez só. Cada patamar só dispara uma vez por posição.
    3. Patamar estatístico do backtest -> se o histórico mostra que a
       maioria dos casos derrapa forte depois desse ponto, sai do resto.
    """
    trades = get_trades_for_mint(mint)
    if not trades:
        return Decision(Action.HOLD, "Sem dados de preço ainda.", 0.0)

    current_cap = trades[-1]["market_cap_sol"] or entry_market_cap_sol
    pct_change = (current_cap - entry_market_cap_sol) / entry_market_cap_sol * 100.0
    already_hit = set(hit_levels.split(",")) if hit_levels else set()

    if pct_change <= settings.stop_loss_pct:
        return Decision(Action.SELL, f"Stop loss atingido ({pct_change:.1f}%).", 1.0)

    if pct_change >= settings.hard_take_profit_pct:
        return Decision(Action.SELL, f"Take profit máximo atingido ({pct_change:.1f}%).", 1.0)

    if time.time() - entry_time >= settings.max_hold_seconds:
        return Decision(Action.SELL, "Tempo máximo de hold atingido.", 0.8)

    for threshold, sell_pct in settings.partial_take_profit_levels:
        level_key = f"L{threshold:.0f}"
        if pct_change >= threshold and level_key not in already_hit:
            return Decision(
                Action.SELL_PARTIAL,
                f"Patamar de realização parcial atingido (+{threshold:.0f}%) — "
                f"vendendo {sell_pct:.0f}% do que resta na posição.",
                0.5,
                sell_pct=sell_pct,
                level_key=level_key,
            )

    # Patamar estatístico: acha o maior threshold já cruzado e olha o
    # histórico de drawdown a partir dele.
    crossed = [s for s in backtest_stats if pct_change >= s.threshold_pct and s.sample_size >= 20]
    if crossed:
        worst = max(crossed, key=lambda s: s.threshold_pct)
        if worst.pct_that_dropped_20pct >= 60:
            return Decision(
                Action.SELL,
                f"Passou de +{worst.threshold_pct:.0f}%, patamar em que "
                f"{worst.pct_that_dropped_20pct:.0f}% dos casos históricos "
                f"caíram >=20% do pico em seguida.",
                0.6,
            )

    return Decision(Action.HOLD, f"Sem gatilho de saída (variação atual: {pct_change:.1f}%).", 0.0)
