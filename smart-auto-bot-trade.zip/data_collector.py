"""
Camada de coleta: conecta no websocket público da PumpPortal
(wss://pumpportal.fun/api/data) e persiste eventos de criação de token
e de trades no banco local.

Isso NÃO precisa de API key (a Data API da PumpPortal é gratuita).
A API key só é necessária depois, na execução de ordens (executor.py).

Limitação importante: esse feed só entrega eventos a partir do momento
em que você conecta. Para ter uma base histórica robusta para backtest,
você precisa rodar isso por um tempo (dias/semanas) ou complementar com
um indexador histórico (Bitquery, Helius, Dune) — ver README.
"""
import asyncio
import json
import logging
import time
from typing import Callable, Optional

import websockets

from config import settings
from database import insert_token, insert_trade
from models import Trade, TokenCreated
from alerts import send_alert

logger = logging.getLogger("data_collector")


def _parse_new_token(msg: dict) -> Optional[TokenCreated]:
    try:
        sol_in_curve = float(msg.get("vSolInBondingCurve", 0) or 0)
        tokens_in_curve = float(msg.get("vTokensInBondingCurve", 0) or 0)
        market_cap = float(msg.get("marketCapSol", 0) or 0)
        return TokenCreated(
            mint=msg["mint"],
            name=msg.get("name", ""),
            symbol=msg.get("symbol", ""),
            creator=msg.get("traderPublicKey", ""),
            created_at=time.time(),
            initial_sol_in_curve=sol_in_curve,
            initial_tokens_in_curve=tokens_in_curve,
            initial_market_cap_sol=market_cap,
            uri=msg.get("uri"),
        )
    except (KeyError, TypeError, ValueError) as e:
        logger.warning("Evento de criação malformado, ignorando: %s (%s)", msg, e)
        return None


def _parse_trade(msg: dict) -> Optional[Trade]:
    try:
        return Trade(
            signature=msg.get("signature", ""),
            mint=msg["mint"],
            trader=msg.get("traderPublicKey", ""),
            tx_type=msg.get("txType", "").lower(),
            sol_amount=float(msg.get("solAmount", 0) or 0),
            token_amount=float(msg.get("tokenAmount", 0) or 0),
            market_cap_sol=float(msg.get("marketCapSol", 0) or 0),
            timestamp=time.time(),
        )
    except (KeyError, TypeError, ValueError) as e:
        logger.warning("Evento de trade malformado, ignorando: %s (%s)", msg, e)
        return None


async def run_collector(on_new_token: Optional[Callable[[TokenCreated], None]] = None) -> None:
    """
    Loop principal de coleta. Reconecta automaticamente em caso de queda.
    `on_new_token` é um callback opcional chamado a cada token novo detectado
    (é aqui que o main.py vai plugar o motor de decisão em tempo real).
    """
    backoff = 1
    while True:
        try:
            async with websockets.connect(settings.pumpportal_ws_url) as ws:
                logger.info("Conectado ao feed da PumpPortal.")
                backoff = 1
                await ws.send(json.dumps({"method": "subscribeNewToken"}))
                await ws.send(json.dumps({"method": "subscribeTokenTrade", "keys": []}))

                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except json.JSONDecodeError:
                        continue

                    tx_type = msg.get("txType")
                    if tx_type == "create":
                        token = _parse_new_token(msg)
                        if token:
                            insert_token(token)
                            logger.info("Novo token: %s (%s) criador=%s",
                                        token.symbol, token.mint[:8], token.creator[:8])
                            if on_new_token:
                                on_new_token(token)
                    elif tx_type in ("buy", "sell"):
                        trade = _parse_trade(msg)
                        if trade:
                            insert_trade(trade)

        except (websockets.exceptions.ConnectionClosed, OSError) as e:
            logger.warning("Conexão perdida (%s). Reconectando em %ss...", e, backoff)
            if backoff >= 60:
                # já tentou várias vezes e chegou no teto de backoff — vale avisar
                send_alert(f"Coletor sem conseguir reconectar à PumpPortal ({e}).", "error")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    from database import init_db
    init_db()
    asyncio.run(run_collector())
