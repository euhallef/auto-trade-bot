"""
Camada de execução. Constrói a transação via PumpPortal (trade-local),
assina LOCALMENTE com sua chave privada (ela nunca sai da sua máquina)
e transmite via sua própria RPC.

REGRAS DE SEGURANÇA — NÃO PULE ISSO:
1. Use uma wallet "quente" dedicada, com SOMENTE o capital que você
   aceita perder 100%. NUNCA a wallet onde você guarda o grosso dos fundos.
2. SOLANA_PRIVATE_KEY vive só no .env local, que deve estar no .gitignore.
   Se esse projeto for para um servidor, use um secrets manager, não .env puro.
3. settings.dry_run começa True. Só mude para False depois de rodar em
   modo simulado por tempo suficiente para confiar no comportamento.
4. slippage e priority_fee em config.py existem por um motivo: sem eles
   sua ordem pode ser executada a um preço bem pior do que o esperado
   (comum em tokens com pouca liquidez).
"""
import logging
import time
from typing import Optional

import requests

from config import settings
from database import record_position_entry, record_position_exit, record_partial_exit
from alerts import send_alert

logger = logging.getLogger("executor")

try:
    from solders.keypair import Keypair
    from solders.transaction import VersionedTransaction
except ImportError:  # solders é opcional até a execução real ser habilitada
    Keypair = None
    VersionedTransaction = None


def _load_keypair() -> Optional["Keypair"]:
    if not settings.wallet_private_key:
        return None
    return Keypair.from_base58_string(settings.wallet_private_key)


def _build_trade_tx(action: str, mint: str, amount, denominated_in_sol: bool, public_key: str) -> bytes:
    """Pede à PumpPortal a transação serializada (não assinada) pronta para assinar localmente."""
    payload = {
        "publicKey": public_key,
        "action": action,  # "buy" ou "sell"
        "mint": mint,
        "amount": amount,  # SOL se denominated_in_sol=True, ou "100%" para vender tudo
        "denominatedInSol": "true" if denominated_in_sol else "false",
        "slippage": settings.slippage_pct,
        "priorityFee": settings.priority_fee_sol,
        "pool": "auto",
    }
    resp = requests.post(settings.pumpportal_trade_url, data=payload, timeout=10)
    resp.raise_for_status()
    return resp.content  # bytes da transação serializada


def _sign_and_send(tx_bytes: bytes, keypair: "Keypair") -> str:
    """Assina a transação localmente e transmite via sua própria RPC."""
    tx = VersionedTransaction.from_bytes(tx_bytes)
    signed_tx = VersionedTransaction(tx.message, [keypair])

    rpc_payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "sendTransaction",
        "params": [
            bytes(signed_tx).hex(),
            {"encoding": "hex", "skipPreflight": False, "maxRetries": 3},
        ],
    }
    resp = requests.post(settings.solana_rpc_url, json=rpc_payload, timeout=15)
    resp.raise_for_status()
    result = resp.json()
    if "error" in result:
        raise RuntimeError(f"Erro da RPC ao enviar transação: {result['error']}")
    return result["result"]  # signature


def buy(mint: str, amount_sol: float, entry_market_cap_sol: float) -> Optional[int]:
    """
    Executa (ou simula, se dry_run) uma compra. Retorna o id da posição
    registrada no banco, para depois fechar com `sell`.
    """
    position_id = record_position_entry(mint, entry_market_cap_sol, amount_sol, settings.dry_run)

    if settings.dry_run:
        logger.info("[DRY_RUN] Compraria %s SOL de %s (posição #%s).", amount_sol, mint, position_id)
        return position_id

    keypair = _load_keypair()
    if keypair is None:
        logger.error("SOLANA_PRIVATE_KEY não configurada — abortando compra real.")
        send_alert(f"Compra de {mint} abortada: SOLANA_PRIVATE_KEY não configurada.", "error")
        return None
    if not settings.solana_rpc_url:
        logger.error("SOLANA_RPC_URL não configurada — abortando compra real.")
        send_alert(f"Compra de {mint} abortada: SOLANA_RPC_URL não configurada.", "error")
        return None

    try:
        tx_bytes = _build_trade_tx("buy", mint, amount_sol, True, str(keypair.pubkey()))
        signature = _sign_and_send(tx_bytes, keypair)
        logger.info("Compra enviada: %s (posição #%s)", signature, position_id)
    except Exception as e:
        logger.exception("Falha ao executar compra real de %s", mint)
        send_alert(f"Falha ao executar compra real de {mint}: {e}", "error")
        return None

    return position_id


def sell(position_id: int, mint: str, exit_market_cap_sol: float, reason: str, amount_pct: str = "100%") -> None:
    """Executa (ou simula) o encerramento de uma posição."""
    record_position_exit(position_id, exit_market_cap_sol, reason)

    if settings.dry_run:
        logger.info("[DRY_RUN] Venderia %s de %s (posição #%s). Motivo: %s",
                    amount_pct, mint, position_id, reason)
        return

    keypair = _load_keypair()
    if keypair is None or not settings.solana_rpc_url:
        logger.error("Configuração incompleta — abortando venda real.")
        send_alert(f"Venda de {mint} (posição #{position_id}) abortada: configuração incompleta. "
                   f"AÇÃO MANUAL PODE SER NECESSÁRIA.", "error")
        return

    try:
        tx_bytes = _build_trade_tx("sell", mint, amount_pct, False, str(keypair.pubkey()))
        signature = _sign_and_send(tx_bytes, keypair)
        logger.info("Venda enviada: %s (posição #%s). Motivo: %s", signature, position_id, reason)
    except Exception as e:
        logger.exception("Falha ao executar venda real de %s", mint)
        send_alert(f"Falha ao executar venda real de {mint} (posição #{position_id}): {e}. "
                   f"AÇÃO MANUAL PODE SER NECESSÁRIA.", "error")


def sell_partial(position_id: int, mint: str, pct_of_remaining: float, level_key: str,
                  market_cap_sol: float, reason: str) -> float:
    """
    Vende só uma fração do que resta na posição (posição continua aberta
    com o restante). `pct_of_remaining` é relativo ao saldo ATUAL de
    tokens na wallet — a própria PumpPortal já entende "50%" dessa forma
    quando denominatedInSol=false, então bate exatamente com a semântica
    que usamos no banco (`record_partial_exit`).
    """
    new_remaining_pct = record_partial_exit(position_id, pct_of_remaining, level_key, market_cap_sol, reason)

    if settings.dry_run:
        logger.info("[DRY_RUN] Venderia %.0f%% do restante de %s (posição #%s). "
                     "Sobra na posição: %.1f%% do original. Motivo: %s",
                     pct_of_remaining, mint, position_id, new_remaining_pct, reason)
        return new_remaining_pct

    keypair = _load_keypair()
    if keypair is None or not settings.solana_rpc_url:
        logger.error("Configuração incompleta — abortando venda parcial real.")
        send_alert(f"Venda parcial de {mint} (posição #{position_id}) abortada: "
                   f"configuração incompleta. AÇÃO MANUAL PODE SER NECESSÁRIA.", "error")
        return new_remaining_pct

    try:
        amount_pct = f"{pct_of_remaining:.0f}%"
        tx_bytes = _build_trade_tx("sell", mint, amount_pct, False, str(keypair.pubkey()))
        signature = _sign_and_send(tx_bytes, keypair)
        logger.info("Venda parcial enviada: %s (posição #%s, %.0f%% do restante). Motivo: %s",
                    signature, position_id, pct_of_remaining, reason)
    except Exception as e:
        logger.exception("Falha ao executar venda parcial real de %s", mint)
        send_alert(f"Falha ao executar venda parcial real de {mint} (posição #{position_id}): {e}. "
                   f"AÇÃO MANUAL PODE SER NECESSÁRIA.", "error")

    return new_remaining_pct
