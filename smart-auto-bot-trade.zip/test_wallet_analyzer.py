import time

from database import insert_token, insert_trade
from models import TokenCreated, Trade
from wallet_analyzer import (
    compute_mint_pnl_for_wallet, compute_wallet_pnl, score_wallet,
    creator_reputation, find_wallet_clusters, build_early_buyer_index,
)


def _mk_token(mint, creator, t0, cap=30.0):
    insert_token(TokenCreated(mint, mint, mint[:4], creator, t0, 1, 900000000, cap))


def test_wallet_pnl_profitable_with_remaining_bag(db):
    t0 = time.time()
    _mk_token("MINTP", "Creator1", t0)
    insert_trade(Trade("s1", "MINTP", "WalletSmart", "buy", 1.0, 1000, 30, t0 + 1))
    insert_trade(Trade("s2", "MINTP", "WalletSmart", "sell", 3.0, 500, 90, t0 + 50))

    pnl = compute_mint_pnl_for_wallet("WalletSmart", "MINTP")
    assert pnl.realized_pnl_sol == 2.0  # gastou 1, recebeu 3
    assert pnl.remaining_tokens == 500
    assert pnl.total_pnl_sol > pnl.realized_pnl_sol  # ainda tem bag com algum valor


def test_wallet_pnl_negative_when_price_crashes(db):
    t0 = time.time()
    _mk_token("MINTN", "Creator1", t0)
    insert_trade(Trade("s1", "MINTN", "WalletRuim", "buy", 5.0, 500, 150, t0 + 1))
    insert_trade(Trade("s2", "MINTN", "Random", "sell", 0.1, 500, 10, t0 + 10))  # preço desaba

    pnl = compute_mint_pnl_for_wallet("WalletRuim", "MINTN")
    assert pnl.total_pnl_sol < 0


def test_compute_wallet_pnl_across_multiple_mints(db):
    t0 = time.time()
    _mk_token("MINTA", "Creator1", t0)
    _mk_token("MINTB", "Creator1", t0)
    insert_trade(Trade("a1", "MINTA", "WalletMulti", "buy", 1.0, 100, 30, t0 + 1))
    insert_trade(Trade("b1", "MINTB", "WalletMulti", "buy", 1.0, 100, 30, t0 + 1))

    results = compute_wallet_pnl("WalletMulti")
    assert {r.mint for r in results} == {"MINTA", "MINTB"}


def test_creator_reputation_detects_rug_pattern(db):
    t0 = time.time() - 10000
    for i in range(4):
        mint = f"RUG{i}"
        _mk_token(mint, "CreatorBad", t0 + i * 100)
        insert_trade(Trade(f"{mint}-1", mint, "trader1", "buy", 1.0, 100, 100, t0 + i * 100 + 1))
        insert_trade(Trade(f"{mint}-2", mint, "trader1", "sell", 0.1, 100, 5, t0 + i * 100 + 50))
    # o mint mais recente (ainda "em andamento") não conta na reputação
    _mk_token("RUGNEW", "CreatorBad", t0 + 1000)

    rep = creator_reputation("CreatorBad")
    assert rep < 0


def test_creator_reputation_neutral_without_history(db):
    _mk_token("SOLO", "CreatorNovo", time.time())
    assert creator_reputation("CreatorNovo") == 0.0


def test_wallet_cluster_detection(db):
    t0 = time.time()
    for i in range(4):
        mint = f"CLUST{i}"
        _mk_token(mint, f"Creator{i}", t0 + i * 10)
        # WalletA e WalletB sempre compram juntas, cedo, nos mesmos tokens
        insert_trade(Trade(f"{mint}-a", mint, "WalletA", "buy", 1.0, 100, 30, t0 + i * 10 + 1))
        insert_trade(Trade(f"{mint}-b", mint, "WalletB", "buy", 1.0, 100, 30, t0 + i * 10 + 2))

    clusters = find_wallet_clusters(min_shared_tokens=3)
    assert frozenset(("WalletA", "WalletB")) in clusters


def test_score_wallet_reflects_pnl_not_just_price_direction(db):
    """
    Uma wallet que vende cedo com lucro deve ser pontuada como BOA mesmo
    que o token depois desabe — isso é o ponto central de usar PnL real
    em vez de só olhar se o preço do token subiu ou caiu no fim.
    """
    t0 = time.time()
    for i in range(3):
        mint = f"EARLYEXIT{i}"
        _mk_token(mint, f"Creator{i}", t0 + i * 10)
        insert_trade(Trade(f"{mint}-1", mint, "SmartExit", "buy", 1.0, 1000, 30, t0 + i * 10 + 1))
        insert_trade(Trade(f"{mint}-2", mint, "SmartExit", "sell", 2.0, 1000, 60, t0 + i * 10 + 5))
        # token desaba DEPOIS que ela já saiu por completo
        insert_trade(Trade(f"{mint}-3", mint, "Random", "sell", 0.05, 500, 3, t0 + i * 10 + 50))

    score = score_wallet("SmartExit")
    assert score.tokens_profitable == 3
    assert score.tokens_unprofitable == 0
    assert score.reputation_score == 1.0
