"""
Checagem de segurança "pré-compra" de um token, via chamadas diretas à
RPC da Solana (não depende da PumpPortal). Verifica dois sinais clássicos
de rug/honeypot:

1. Mint authority não revogada -> o criador pode mintar tokens novos do
   nada, diluindo (ou zerando) quem já comprou.
2. Freeze authority não revogada -> o criador pode congelar as contas de
   outras wallets, impedindo que elas vendam (honeypot clássico).
3. Concentração de supply fora da bonding curve -> se uma wallet (que não
   seja a própria bonding curve da pump.fun) concentra uma fatia grande
   do supply, ela pode despejar tudo de uma vez.

Tokens criados pelo fluxo padrão da pump.fun já vêm com mint/freeze
authority revogadas automaticamente — isso aqui serve para PEGAR OS CASOS
QUE FOGEM DO PADRÃO (programas clonados/alterados, ou tokens que não
passaram pelo fluxo normal), não para desconfiar da pump.fun em si.

Precisa de SOLANA_RPC_URL configurada. Se não estiver configurada, ou se
ENABLE_SAFETY_CHECK=false, a checagem é pulada (retorna "seguro, mas não
verificado") — isso é intencional para permitir rodar só a coleta de
dados sem precisar de RPC.
"""
import base64
import logging
import struct
from typing import List, Optional, Tuple

import requests
from solders.pubkey import Pubkey

from config import settings

logger = logging.getLogger("token_safety")

PUMP_PROGRAM_ID = Pubkey.from_string("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P")
TOKEN_PROGRAM_ID = Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
ASSOCIATED_TOKEN_PROGRAM_ID = Pubkey.from_string("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL")

MINT_LAYOUT_SIZE = 82  # tamanho do struct Mint padrão do SPL Token (sem extensões Token-2022)

# Layout da conta BondingCurve do programa da pump.fun (confirmado via IDL/decoders
# públicos: carbon-pumpfun-decoder, pumpfun-sdk). 8 bytes de discriminator Anchor,
# depois 5 campos u64 e um bool. Versões mais novas anexam o pubkey do `creator`
# no final (32 bytes) — tratamos isso como opcional.
BONDING_CURVE_DISCRIMINATOR = bytes([0x17, 0xB7, 0xF8, 0x37, 0x60, 0xD8, 0xAC, 0x60])
_BC_OFF_VIRTUAL_TOKEN_RESERVES = 8
_BC_OFF_VIRTUAL_SOL_RESERVES = 16
_BC_OFF_REAL_TOKEN_RESERVES = 24
_BC_OFF_REAL_SOL_RESERVES = 32
_BC_OFF_TOKEN_TOTAL_SUPPLY = 40
_BC_OFF_COMPLETE = 48
_BC_MIN_SIZE = 49  # discriminator(8) + 5*u64(40) + complete(1)


def _rpc_call(method: str, params: list):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    resp = requests.post(
        settings.solana_rpc_url, json=payload, timeout=settings.safety_check_timeout_seconds
    )
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"RPC error em {method}: {data['error']}")
    return data["result"]


def get_bonding_curve_ata(mint: str) -> str:
    """
    Deriva o endereço da associated token account da bonding curve da
    pump.fun para esse mint — é essa conta que naturalmente detém a
    maior parte do supply enquanto o token não migrou pra Raydium/PumpSwap.
    """
    mint_pk = Pubkey.from_string(mint)
    bonding_curve_pda = Pubkey.from_string(get_bonding_curve_pda(mint))
    ata, _ = Pubkey.find_program_address(
        [bytes(bonding_curve_pda), bytes(TOKEN_PROGRAM_ID), bytes(mint_pk)],
        ASSOCIATED_TOKEN_PROGRAM_ID,
    )
    return str(ata)


def get_bonding_curve_pda(mint: str) -> str:
    mint_pk = Pubkey.from_string(mint)
    pda, _ = Pubkey.find_program_address([b"bonding-curve", bytes(mint_pk)], PUMP_PROGRAM_ID)
    return str(pda)


def get_bonding_curve_state(mint: str) -> Optional[dict]:
    """
    Lê e decodifica a conta BondingCurve on-chain. O campo `complete`
    é a fonte de verdade de que o token "graduou" e migrou para um AMM
    (Raydium ou PumpSwap) — depois disso, a lógica de preço baseada na
    bonding curve deixa de valer.

    Retorna None se a checagem não puder ser feita (sem RPC configurada,
    conta não encontrada, ou layout inesperado — ex: programa de uma
    versão futura que mudou o formato da conta).
    """
    if not settings.solana_rpc_url:
        return None
    try:
        pda = get_bonding_curve_pda(mint)
        result = _rpc_call("getAccountInfo", [pda, {"encoding": "base64"}])
        if not result or not result.get("value"):
            return None
        raw = base64.b64decode(result["value"]["data"][0])
        if len(raw) < _BC_MIN_SIZE:
            return None
        if raw[:8] != BONDING_CURVE_DISCRIMINATOR:
            logger.warning("Discriminator inesperado na conta bonding curve de %s — "
                            "layout pode ter mudado.", mint)
            return None

        return {
            "virtual_token_reserves": struct.unpack_from("<Q", raw, _BC_OFF_VIRTUAL_TOKEN_RESERVES)[0],
            "virtual_sol_reserves": struct.unpack_from("<Q", raw, _BC_OFF_VIRTUAL_SOL_RESERVES)[0],
            "real_token_reserves": struct.unpack_from("<Q", raw, _BC_OFF_REAL_TOKEN_RESERVES)[0],
            "real_sol_reserves": struct.unpack_from("<Q", raw, _BC_OFF_REAL_SOL_RESERVES)[0],
            "token_total_supply": struct.unpack_from("<Q", raw, _BC_OFF_TOKEN_TOTAL_SUPPLY)[0],
            "complete": bool(raw[_BC_OFF_COMPLETE]),
        }
    except Exception:
        logger.exception("Falha ao ler estado da bonding curve de %s", mint)
        return None


def has_graduated(mint: str) -> Optional[bool]:
    """True/False se foi possível checar, None se não (sem RPC ou erro)."""
    state = get_bonding_curve_state(mint)
    if state is None:
        return None
    return state["complete"]


def get_mint_info(mint: str) -> Optional[dict]:
    """Busca e decodifica a conta Mint (SPL Token) via RPC. None se falhar."""
    try:
        result = _rpc_call("getAccountInfo", [mint, {"encoding": "base64"}])
        if not result or not result.get("value"):
            return None
        raw = base64.b64decode(result["value"]["data"][0])
        if len(raw) < MINT_LAYOUT_SIZE:
            return None

        mint_auth_opt = struct.unpack_from("<I", raw, 0)[0]
        mint_auth_bytes = raw[4:36]
        supply = struct.unpack_from("<Q", raw, 36)[0]
        decimals = raw[44]
        freeze_auth_opt = struct.unpack_from("<I", raw, 46)[0]
        freeze_auth_bytes = raw[50:82]

        return {
            "mint_authority": str(Pubkey(mint_auth_bytes)) if mint_auth_opt == 1 else None,
            "freeze_authority": str(Pubkey(freeze_auth_bytes)) if freeze_auth_opt == 1 else None,
            "supply": supply,
            "decimals": decimals,
        }
    except Exception:
        logger.exception("Falha ao buscar/decodificar conta mint de %s", mint)
        return None


def get_largest_holders(mint: str) -> List[dict]:
    """Retorna até 20 maiores contas holder (token accounts) via RPC. Lista vazia se falhar."""
    try:
        result = _rpc_call("getTokenLargestAccounts", [mint])
        return result.get("value", []) if result else []
    except Exception:
        logger.exception("Falha ao buscar maiores holders de %s", mint)
        return []


def check_token_safety(mint: str) -> Tuple[bool, List[str]]:
    """
    Retorna (is_safe, motivos). is_safe=False significa que pelo menos um
    sinal de risco concreto foi encontrado — trate como veto de compra,
    não como sugestão.
    """
    if not settings.enable_safety_check:
        return True, ["Checagem de segurança desabilitada em config (ENABLE_SAFETY_CHECK=false)."]

    if not settings.solana_rpc_url:
        return True, ["SOLANA_RPC_URL não configurada — checagem pulada, NÃO verificado."]

    reasons: List[str] = []
    is_safe = True

    mint_info = get_mint_info(mint)
    if mint_info is None:
        return True, ["Não foi possível ler a conta mint (timeout ou RPC instável) — NÃO verificado."]

    if mint_info["mint_authority"] is not None:
        is_safe = False
        reasons.append("Mint authority NÃO revogada — criador pode criar mais tokens a qualquer momento.")

    if mint_info["freeze_authority"] is not None:
        is_safe = False
        reasons.append("Freeze authority NÃO revogada — criador pode congelar contas de holders (honeypot).")

    try:
        bonding_curve_ata = get_bonding_curve_ata(mint)
    except Exception:
        bonding_curve_ata = None
        logger.exception("Falha ao derivar ATA da bonding curve para %s", mint)

    holders = get_largest_holders(mint)
    total_supply = mint_info["supply"] or 1
    for holder in holders:
        if bonding_curve_ata and holder.get("address") == bonding_curve_ata:
            continue  # supply na própria bonding curve é esperado, não é risco
        amount = int(holder.get("amount", 0))
        pct = amount / total_supply * 100.0
        if pct >= settings.max_top_holder_pct:
            is_safe = False
            reasons.append(
                f"Wallet fora da bonding curve concentra {pct:.1f}% do supply "
                f"(limite configurado: {settings.max_top_holder_pct}%)."
            )
            break  # um achado já basta para reprovar

    if not reasons:
        reasons.append("Mint/freeze authority revogadas e sem concentração anormal de supply.")

    return is_safe, reasons
