import base64
import struct

from solders.pubkey import Pubkey

import token_safety as ts
from config import settings


def _build_mint_bytes(mint_auth=None, freeze_auth=None, supply=1_000_000_000, decimals=6):
    buf = bytearray(82)
    if mint_auth:
        struct.pack_into("<I", buf, 0, 1)
        buf[4:36] = bytes(mint_auth)
    struct.pack_into("<Q", buf, 36, supply)
    buf[44] = decimals
    buf[45] = 1
    if freeze_auth:
        struct.pack_into("<I", buf, 46, 1)
        buf[50:82] = bytes(freeze_auth)
    return bytes(buf)


def _build_curve_bytes(complete=False):
    buf = bytearray(49)
    buf[0:8] = ts.BONDING_CURVE_DISCRIMINATOR
    struct.pack_into("<Q", buf, 8, 500_000_000)
    struct.pack_into("<Q", buf, 16, 30_000_000_000)
    struct.pack_into("<Q", buf, 24, 400_000_000)
    struct.pack_into("<Q", buf, 32, 25_000_000_000)
    struct.pack_into("<Q", buf, 40, 1_000_000_000)
    buf[48] = 1 if complete else 0
    return bytes(buf)


def test_get_mint_info_parses_revoked_authorities(monkeypatch):
    raw = _build_mint_bytes()
    b64 = base64.b64encode(raw).decode()
    monkeypatch.setattr(ts, "_rpc_call", lambda method, params: {"value": {"data": [b64, "base64"]}})

    info = ts.get_mint_info(str(Pubkey.new_unique()))
    assert info["mint_authority"] is None
    assert info["freeze_authority"] is None
    assert info["supply"] == 1_000_000_000


def test_get_mint_info_parses_active_authority(monkeypatch):
    evil = Pubkey.new_unique()
    raw = _build_mint_bytes(mint_auth=evil)
    b64 = base64.b64encode(raw).decode()
    monkeypatch.setattr(ts, "_rpc_call", lambda method, params: {"value": {"data": [b64, "base64"]}})

    info = ts.get_mint_info(str(Pubkey.new_unique()))
    assert info["mint_authority"] == str(evil)


def test_bonding_curve_state_detects_graduation(monkeypatch):
    monkeypatch.setattr(settings, "solana_rpc_url", "http://fake-rpc")
    raw = _build_curve_bytes(complete=True)
    b64 = base64.b64encode(raw).decode()
    monkeypatch.setattr(ts, "_rpc_call", lambda method, params: {"value": {"data": [b64, "base64"]}})

    assert ts.has_graduated(str(Pubkey.new_unique())) is True


def test_bonding_curve_state_none_without_rpc(monkeypatch):
    monkeypatch.setattr(settings, "solana_rpc_url", "")
    assert ts.get_bonding_curve_state(str(Pubkey.new_unique())) is None
    assert ts.has_graduated(str(Pubkey.new_unique())) is None


def test_check_token_safety_skips_without_rpc(monkeypatch):
    monkeypatch.setattr(settings, "solana_rpc_url", "")
    monkeypatch.setattr(settings, "enable_safety_check", True)
    is_safe, reasons = ts.check_token_safety(str(Pubkey.new_unique()))
    assert is_safe is True
    assert "NÃO verificado" in reasons[0]


def test_check_token_safety_vetoes_active_mint_authority(monkeypatch):
    monkeypatch.setattr(settings, "solana_rpc_url", "http://fake-rpc")
    monkeypatch.setattr(settings, "enable_safety_check", True)
    evil = Pubkey.new_unique()
    raw = _build_mint_bytes(mint_auth=evil)
    b64 = base64.b64encode(raw).decode()

    def fake_rpc(method, params):
        if method == "getAccountInfo":
            return {"value": {"data": [b64, "base64"]}}
        return {"value": []}

    monkeypatch.setattr(ts, "_rpc_call", fake_rpc)
    is_safe, reasons = ts.check_token_safety(str(Pubkey.new_unique()))
    assert is_safe is False
    assert any("Mint authority" in r for r in reasons)


def test_check_token_safety_passes_clean_token(monkeypatch):
    monkeypatch.setattr(settings, "solana_rpc_url", "http://fake-rpc")
    monkeypatch.setattr(settings, "enable_safety_check", True)
    raw = _build_mint_bytes()
    b64 = base64.b64encode(raw).decode()

    def fake_rpc(method, params):
        if method == "getAccountInfo":
            return {"value": {"data": [b64, "base64"]}}
        return {"value": []}  # sem holders concentrados

    monkeypatch.setattr(ts, "_rpc_call", fake_rpc)
    is_safe, reasons = ts.check_token_safety(str(Pubkey.new_unique()))
    assert is_safe is True
