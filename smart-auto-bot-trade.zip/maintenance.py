"""
Manutenção periódica do banco local. A tabela `trades` cresce sem limite
enquanto o coletor roda — isso aqui move (ou descarta) trades antigos
para manter o banco principal rápido de consultar.

Uso recomendado: rodar semanalmente via cron, mantendo uns 30-60 dias de
histórico "quente" no banco principal.

    python maintenance.py --days 30                    # arquiva em pumpfun_data.archive.sqlite3
    python maintenance.py --days 30 --no-archive        # só apaga, sem guardar em outro arquivo
    python maintenance.py --days 30 --archive-path /caminho/custom.sqlite3
"""
import argparse
import logging
import time

from config import settings
from database import archive_old_trades

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("maintenance")


def main() -> None:
    parser = argparse.ArgumentParser(description="Arquiva/limpa trades antigos do banco local.")
    parser.add_argument("--days", type=int, default=30,
                         help="Mantém trades dos últimos N dias no banco principal (padrão: 30).")
    parser.add_argument("--archive-path", type=str, default=None,
                         help="Caminho do arquivo SQLite de arquivo. "
                              "Padrão: <DB_PATH sem extensão>.archive.sqlite3")
    parser.add_argument("--no-archive", action="store_true",
                         help="Não guarda os trades removidos em nenhum lugar, só apaga.")
    args = parser.parse_args()

    cutoff = time.time() - args.days * 86400

    archive_path = None
    if not args.no_archive:
        archive_path = args.archive_path or settings.db_path.rsplit(".", 1)[0] + ".archive.sqlite3"

    logger.info("Arquivando trades anteriores a %d dias atrás (%s)...", args.days,
                "sem cópia" if archive_path is None else f"cópia em {archive_path}")
    count = archive_old_trades(cutoff, archive_path)
    logger.info("Concluído: %d trades removidos do banco principal.", count)


if __name__ == "__main__":
    main()
