"""
Orquestrador principal.

Fluxo:
1. Sobe o coletor de dados em background (data_collector.py).
2. A cada novo token detectado, roda a estratégia de entrada (strategy.py),
   usando reputação de wallet (wallet_analyzer.py) + o backtest mais
   recente (backtester.py).
3. Um loop paralelo monitora posições abertas e decide quando sair.
4. Toda execução passa por executor.py, que respeita settings.dry_run.

Rode com: python main.py
Pare com: Ctrl+C

LEMBRETE: comece SEMPRE com DRY_RUN=true no .env. Rode assim por dias,
revise o log e os `bot_positions` no banco antes de sequer considerar
DRY_RUN=false.
"""
import asyncio
import logging
import time

from config import settings
from database import init_db, get_open_positions, get_trades_for_mint, get_ungraduated_tokens_with_open_positions, mark_token_graduated
from data_collector import run_collector
from models import TokenCreated
from backtester import run_full_backtest
from strategy import should_enter, should_exit, Action
from executor import buy, sell, sell_partial
from token_safety import check_token_safety, has_graduated
from alerts import send_alert

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("main")

# cache do backtest, recalculado periodicamente em vez de a cada evento
_backtest_cache = []
_backtest_cache_time = 0.0
BACKTEST_REFRESH_SECONDS = 900  # recalcula a cada 15 min


def get_backtest_stats():
    global _backtest_cache, _backtest_cache_time
    if time.time() - _backtest_cache_time > BACKTEST_REFRESH_SECONDS:
        logger.info("Recalculando backtest de patamares...")
        _backtest_cache = run_full_backtest()
        _backtest_cache_time = time.time()
    return _backtest_cache


def on_new_token(token: TokenCreated) -> None:
    """Callback chamado pelo coletor toda vez que um token novo é detectado."""
    stats = get_backtest_stats()
    decision = should_enter(token, stats)

    logger.info("Token %s (%s): %s -> %s (confiança=%.2f)",
                token.symbol, token.mint[:8], decision.reason, decision.action.value, decision.confidence)

    if decision.action != Action.BUY:
        return

    # --- Gate 1: limite de exposição simultânea ---
    open_positions = get_open_positions()
    if len(open_positions) >= settings.max_concurrent_positions:
        logger.info("Limite de %s posições simultâneas atingido — pulando %s.",
                     settings.max_concurrent_positions, token.symbol)
        return

    # --- Gate 2: checagem de segurança do token (mint/freeze authority, concentração) ---
    is_safe, reasons = check_token_safety(token.mint)
    if not is_safe:
        logger.warning("Token %s reprovado na checagem de segurança: %s", token.symbol, "; ".join(reasons))
        send_alert(f"Compra bloqueada em {token.symbol} ({token.mint[:8]}): {'; '.join(reasons)}", "warning")
        return

    amount = settings.max_position_sol * decision.confidence
    amount = max(amount, 0.01)  # piso mínimo de posição
    position_id = buy(token.mint, amount, token.initial_market_cap_sol)
    if position_id is not None:
        send_alert(
            f"Compra {'(DRY_RUN) ' if settings.dry_run else ''}em {token.symbol} ({token.mint[:8]}): "
            f"{amount:.3f} SOL. Motivo: {decision.reason}",
            "buy",
        )


async def monitor_open_positions() -> None:
    """Loop separado que reavalia posições abertas periodicamente."""
    while True:
        stats = get_backtest_stats()
        for pos in get_open_positions():
            decision = should_exit(
                pos["mint"], pos["entry_market_cap_sol"], pos["entry_time"], stats,
                hit_levels=pos["hit_levels"],
            )
            trades = get_trades_for_mint(pos["mint"])
            current_cap = trades[-1]["market_cap_sol"] if trades else pos["entry_market_cap_sol"]

            if decision.action == Action.SELL:
                sell(pos["id"], pos["mint"], current_cap, decision.reason)
                send_alert(
                    f"Venda {'(DRY_RUN) ' if settings.dry_run else ''}de {pos['mint'][:8]} "
                    f"(posição #{pos['id']}). Motivo: {decision.reason}",
                    "sell",
                )
            elif decision.action == Action.SELL_PARTIAL:
                remaining = sell_partial(
                    pos["id"], pos["mint"], decision.sell_pct, decision.level_key,
                    current_cap, decision.reason,
                )
                send_alert(
                    f"Venda parcial {'(DRY_RUN) ' if settings.dry_run else ''}de {pos['mint'][:8]} "
                    f"(posição #{pos['id']}, restam {remaining:.0f}% da posição original). "
                    f"Motivo: {decision.reason}",
                    "sell",
                )
        await asyncio.sleep(5)


async def monitor_graduations() -> None:
    """
    Loop separado (roda com menos frequência, cada checagem é uma chamada
    de RPC) que verifica se algum token com posição aberta migrou da
    bonding curve para um AMM. Isso muda a dinâmica de preço, então vale
    saber assim que acontece — mesmo que a decisão de saída em si continue
    vindo de should_exit().
    """
    while True:
        for mint in get_ungraduated_tokens_with_open_positions():
            graduated = has_graduated(mint)
            if graduated:
                mark_token_graduated(mint)
                logger.info("Token %s graduou da bonding curve para AMM.", mint[:8])
                send_alert(
                    f"Token {mint[:8]} migrou da bonding curve para um AMM "
                    f"(Raydium/PumpSwap) — dinâmica de preço mudou de regime.",
                    "info",
                )
        await asyncio.sleep(30)


async def main() -> None:
    init_db()
    logger.info("Iniciando bot. DRY_RUN=%s", settings.dry_run)
    send_alert(f"Bot iniciado (DRY_RUN={settings.dry_run}, "
               f"max_posicoes={settings.max_concurrent_positions}).", "info")
    if not settings.dry_run:
        logger.warning("!!! MODO DE EXECUÇÃO REAL ATIVADO !!! Ordens reais serão enviadas.")
        send_alert("MODO DE EXECUÇÃO REAL ATIVADO — ordens reais serão enviadas.", "warning")

    await asyncio.gather(
        run_collector(on_new_token=on_new_token),
        monitor_open_positions(),
        monitor_graduations(),
    )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Encerrado pelo usuário.")
        send_alert("Bot encerrado manualmente.", "info")
    except Exception:
        logger.exception("Bot encerrado por erro não tratado.")
        send_alert("Bot CAIU por um erro não tratado — veja o log.", "error")
        raise
