"""
Envia notificações para fora do processo (Discord e/ou Telegram), pra você
saber o que o bot está fazendo sem precisar ficar olhando o log o tempo
todo. Rodando sem supervisão, isso é o que te avisa se algo travou.

Configuração é opcional: se nenhum webhook/token estiver setado no .env,
os alertas só vão para o log local — o bot continua funcionando normal.

Falha ao enviar alerta NUNCA deve derrubar o bot — por isso tudo aqui é
best-effort com try/except.
"""
import logging

import requests

from config import settings

logger = logging.getLogger("alerts")

_ICONS = {"info": "ℹ️", "buy": "🟢", "sell": "🔴", "warning": "⚠️", "error": "🚨"}


def send_alert(message: str, level: str = "info") -> None:
    """Envia o alerta para todos os canais configurados. Nunca lança exceção."""
    icon = _ICONS.get(level, "ℹ️")
    full_message = f"{icon} {message}"

    logger.info("ALERTA[%s]: %s", level, message)

    if settings.discord_webhook_url:
        _send_discord(full_message)

    if settings.telegram_bot_token and settings.telegram_chat_id:
        _send_telegram(full_message)


def _send_discord(message: str) -> None:
    try:
        resp = requests.post(
            settings.discord_webhook_url,
            json={"content": message},
            timeout=5,
        )
        resp.raise_for_status()
    except Exception:
        logger.exception("Falha ao enviar alerta para o Discord (bot continua rodando).")


def _send_telegram(message: str) -> None:
    try:
        url = f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage"
        resp = requests.post(
            url,
            json={"chat_id": settings.telegram_chat_id, "text": message},
            timeout=5,
        )
        resp.raise_for_status()
    except Exception:
        logger.exception("Falha ao enviar alerta para o Telegram (bot continua rodando).")
