"""
Camada de persistência. SQLite simples — suficiente para rodar localmente
e fazer as análises. Se o volume crescer muito, trocar por Postgres é
uma troca de poucas linhas aqui (as queries usam SQL padrão).
"""
import sqlite3
import time
from contextlib import contextmanager
from typing import Iterator, List, Optional, Tuple

from config import settings
from models import Trade, TokenCreated

SCHEMA = """
CREATE TABLE IF NOT EXISTS tokens (
    mint TEXT PRIMARY KEY,
    name TEXT,
    symbol TEXT,
    creator TEXT NOT NULL,
    created_at REAL NOT NULL,
    initial_sol_in_curve REAL,
    initial_tokens_in_curve REAL,
    initial_market_cap_sol REAL,
    uri TEXT,
    graduated_at REAL
);

CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature TEXT,
    mint TEXT NOT NULL,
    trader TEXT NOT NULL,
    tx_type TEXT NOT NULL,
    sol_amount REAL,
    token_amount REAL,
    market_cap_sol REAL,
    timestamp REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_trades_mint ON trades(mint);
CREATE INDEX IF NOT EXISTS idx_trades_trader ON trades(trader);
CREATE INDEX IF NOT EXISTS idx_tokens_creator ON tokens(creator);

CREATE TABLE IF NOT EXISTS bot_positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mint TEXT NOT NULL,
    entry_time REAL NOT NULL,
    entry_market_cap_sol REAL NOT NULL,
    entry_sol_amount REAL NOT NULL,
    remaining_pct REAL NOT NULL DEFAULT 100.0,
    hit_levels TEXT NOT NULL DEFAULT '',
    exit_time REAL,
    exit_market_cap_sol REAL,
    exit_reason TEXT,
    dry_run INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS position_exits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    position_id INTEGER NOT NULL,
    exit_time REAL NOT NULL,
    pct_of_original_sold REAL NOT NULL,
    market_cap_sol REAL,
    reason TEXT
);
"""

# Colunas adicionadas depois do lançamento inicial do projeto. init_db()
# aplica isso em bancos já existentes, sem apagar dados (SQLite não tem
# "ADD COLUMN IF NOT EXISTS", então checamos o schema manualmente).
_MIGRATIONS = {
    "tokens": [("graduated_at", "REAL")],
    "bot_positions": [("remaining_pct", "REAL NOT NULL DEFAULT 100.0"),
                       ("hit_levels", "TEXT NOT NULL DEFAULT ''")],
}


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(settings.db_path)
    conn.execute("PRAGMA journal_mode=WAL;")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        for table, columns in _MIGRATIONS.items():
            existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
            for col_name, col_def in columns:
                if col_name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")


def insert_token(t: TokenCreated) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT OR IGNORE INTO tokens
               (mint, name, symbol, creator, created_at, initial_sol_in_curve,
                initial_tokens_in_curve, initial_market_cap_sol, uri)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (t.mint, t.name, t.symbol, t.creator, t.created_at,
             t.initial_sol_in_curve, t.initial_tokens_in_curve,
             t.initial_market_cap_sol, t.uri),
        )


def insert_trade(t: Trade) -> None:
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO trades
               (signature, mint, trader, tx_type, sol_amount, token_amount,
                market_cap_sol, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (t.signature, t.mint, t.trader, t.tx_type, t.sol_amount,
             t.token_amount, t.market_cap_sol, t.timestamp),
        )


def get_token(mint: str) -> Optional[sqlite3.Row]:
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute("SELECT * FROM tokens WHERE mint = ?", (mint,))
        return cur.fetchone()


def get_trades_for_mint(mint: str) -> List[sqlite3.Row]:
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute(
            "SELECT * FROM trades WHERE mint = ? ORDER BY timestamp ASC", (mint,)
        )
        return cur.fetchall()


def get_all_tokens() -> List[sqlite3.Row]:
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute("SELECT * FROM tokens ORDER BY created_at ASC")
        return cur.fetchall()


def get_tokens_by_creator(creator: str) -> List[sqlite3.Row]:
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute(
            "SELECT * FROM tokens WHERE creator = ? ORDER BY created_at ASC", (creator,)
        )
        return cur.fetchall()


def get_trades_for_wallet(wallet: str) -> List[sqlite3.Row]:
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute(
            "SELECT * FROM trades WHERE trader = ? ORDER BY timestamp ASC", (wallet,)
        )
        return cur.fetchall()


def record_position_entry(mint: str, market_cap_sol: float, sol_amount: float, dry_run: bool) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO bot_positions (mint, entry_time, entry_market_cap_sol,
               entry_sol_amount, dry_run) VALUES (?, ?, ?, ?, ?)""",
            (mint, time.time(), market_cap_sol, sol_amount, int(dry_run)),
        )
        return cur.lastrowid


def record_position_exit(position_id: int, market_cap_sol: float, reason: str) -> None:
    """Encerra a posição por completo (usado por stop loss, take profit total e timeout)."""
    with get_conn() as conn:
        conn.execute(
            """UPDATE bot_positions SET exit_time = ?, exit_market_cap_sol = ?,
               exit_reason = ?, remaining_pct = 0 WHERE id = ?""",
            (time.time(), market_cap_sol, reason, position_id),
        )
        conn.execute(
            """INSERT INTO position_exits (position_id, exit_time, pct_of_original_sold,
               market_cap_sol, reason) SELECT id, ?, remaining_pct, ?, ? FROM bot_positions
               WHERE id = ?""",
            (time.time(), market_cap_sol, reason, position_id),
        )


def record_partial_exit(position_id: int, pct_of_remaining_sold: float, level_key: str,
                         market_cap_sol: float, reason: str) -> float:
    """
    Vende uma fração do que resta na posição (não a posição toda).
    `pct_of_remaining_sold` é relativo ao que ainda está aberto (ex: 50 =
    metade do que resta agora, não 50% da posição original).
    Retorna o `remaining_pct` (sobre o total original) depois da venda.
    """
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT remaining_pct, hit_levels FROM bot_positions WHERE id = ?",
                            (position_id,)).fetchone()
        if row is None:
            return 0.0

        remaining_before = row["remaining_pct"]
        pct_of_original_sold_now = remaining_before * (pct_of_remaining_sold / 100.0)
        new_remaining = max(remaining_before - pct_of_original_sold_now, 0.0)
        new_hit_levels = (row["hit_levels"] + "," + level_key).strip(",")

        conn.execute(
            "UPDATE bot_positions SET remaining_pct = ?, hit_levels = ? WHERE id = ?",
            (new_remaining, new_hit_levels, position_id),
        )
        conn.execute(
            """INSERT INTO position_exits (position_id, exit_time, pct_of_original_sold,
               market_cap_sol, reason) VALUES (?, ?, ?, ?, ?)""",
            (position_id, time.time(), pct_of_original_sold_now, market_cap_sol, reason),
        )

        if new_remaining <= 0.5:  # o que sobrou é poeira, considera a posição encerrada
            conn.execute(
                "UPDATE bot_positions SET exit_time = ?, exit_market_cap_sol = ?, "
                "exit_reason = ? WHERE id = ?",
                (time.time(), market_cap_sol, f"{reason} (última fatia)", position_id),
            )

        return new_remaining


def get_open_positions() -> List[sqlite3.Row]:
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.execute("SELECT * FROM bot_positions WHERE exit_time IS NULL")
        return cur.fetchall()


def mark_token_graduated(mint: str, graduated_at: Optional[float] = None) -> None:
    """Marca um token como migrado da bonding curve para AMM (Raydium/PumpSwap)."""
    with get_conn() as conn:
        conn.execute(
            "UPDATE tokens SET graduated_at = ? WHERE mint = ? AND graduated_at IS NULL",
            (graduated_at or time.time(), mint),
        )


def get_ungraduated_tokens_with_open_positions() -> List[str]:
    """Mints com posição aberta e ainda não marcados como graduados — candidatos a checar."""
    with get_conn() as conn:
        cur = conn.execute(
            """SELECT DISTINCT bp.mint FROM bot_positions bp
               JOIN tokens t ON t.mint = bp.mint
               WHERE bp.exit_time IS NULL AND t.graduated_at IS NULL"""
        )
        return [row[0] for row in cur.fetchall()]


def archive_old_trades(cutoff_timestamp: float, archive_path: Optional[str] = None) -> int:
    """
    Move trades mais antigos que `cutoff_timestamp` para um arquivo SQLite
    separado (ou só apaga, se archive_path=None) e faz VACUUM no banco
    principal. Retorna quantas linhas foram arquivadas/removidas.

    Pensado para rodar periodicamente (ex: cron semanal) e manter o banco
    principal enxuto, sem perder o histórico bruto se você quiser mantê-lo.
    """
    with get_conn() as conn:
        cur = conn.execute("SELECT COUNT(*) FROM trades WHERE timestamp < ?", (cutoff_timestamp,))
        count = cur.fetchone()[0]
        if count == 0:
            return 0

        if archive_path:
            conn.execute("ATTACH DATABASE ? AS archive", (archive_path,))
            conn.execute("""
                CREATE TABLE IF NOT EXISTS archive.trades AS
                SELECT * FROM trades WHERE 0
            """)
            conn.execute(
                "INSERT INTO archive.trades SELECT * FROM trades WHERE timestamp < ?",
                (cutoff_timestamp,),
            )
            conn.commit()  # fecha a transação antes de tentar destacar o banco de arquivo
            conn.execute("DETACH DATABASE archive")

        conn.execute("DELETE FROM trades WHERE timestamp < ?", (cutoff_timestamp,))

    with get_conn() as conn:
        conn.execute("VACUUM")

    return count
