"""
Configuração central. Tudo sensível vem de variáveis de ambiente (.env),
nunca hardcoded no código.
"""
import os
from dataclasses import dataclass, field
from typing import List

from dotenv import load_dotenv

load_dotenv()


def _get_bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def _get_float_list(name: str, default: List[float]) -> List[float]:
    val = os.getenv(name)
    if not val:
        return default
    return [float(x.strip()) for x in val.split(",") if x.strip()]


def _get_level_pairs(name: str, default: List[tuple]) -> List[tuple]:
    """Parseia 'threshold:pct,threshold:pct' -> [(threshold, pct), ...], ordenado por threshold."""
    val = os.getenv(name)
    if not val:
        return default
    pairs = []
    for chunk in val.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        threshold_str, pct_str = chunk.split(":")
        pairs.append((float(threshold_str), float(pct_str)))
    return sorted(pairs, key=lambda p: p[0])


@dataclass
class Settings:
    # --- Segurança / modo de operação ---
    # DRY_RUN=true (padrão) => o bot decide e loga, mas NUNCA envia transação real.
    dry_run: bool = field(default_factory=lambda: _get_bool("DRY_RUN", True))

    # --- Conectividade ---
    pumpportal_ws_url: str = os.getenv("PUMPPORTAL_WS_URL", "wss://pumpportal.fun/api/data")
    pumpportal_trade_url: str = os.getenv("PUMPPORTAL_TRADE_URL", "https://pumpportal.fun/api/trade-local")
    solana_rpc_url: str = os.getenv("SOLANA_RPC_URL", "")  # obrigatório para execução real
    wallet_private_key: str = os.getenv("SOLANA_PRIVATE_KEY", "")  # base58, NUNCA versionar

    # --- Banco de dados local ---
    db_path: str = os.getenv("DB_PATH", "pumpfun_data.sqlite3")

    # --- Parâmetros de análise de wallets ---
    early_buyer_window: int = int(os.getenv("EARLY_BUYER_WINDOW", "10"))  # top N compradores considerados "early"
    min_tokens_for_reputation: int = int(os.getenv("MIN_TOKENS_FOR_REPUTATION", "3"))

    # --- Parâmetros de backtest / patamares de valorização testados ---
    thresholds_pct: List[float] = field(
        default_factory=lambda: _get_float_list(
            "THRESHOLDS_PCT", [50, 100, 150, 200, 300, 500, 1000]
        )
    )
    forward_window_seconds: int = int(os.getenv("FORWARD_WINDOW_SECONDS", "600"))  # janela de 10min p/ medir o que acontece depois

    # --- Gestão de risco (obrigatória, não opcional) ---
    max_position_sol: float = float(os.getenv("MAX_POSITION_SOL", "0.1"))
    stop_loss_pct: float = float(os.getenv("STOP_LOSS_PCT", "-30"))       # sai se cair 30% do preço de entrada
    hard_take_profit_pct: float = float(os.getenv("HARD_TAKE_PROFIT_PCT", "1000"))  # sai sempre acima disso, sem exceção
    max_hold_seconds: int = int(os.getenv("MAX_HOLD_SECONDS", "1800"))    # sai se ficar mais de 30min sem bater stop/take
    slippage_pct: float = float(os.getenv("SLIPPAGE_PCT", "10"))
    priority_fee_sol: float = float(os.getenv("PRIORITY_FEE_SOL", "0.0005"))

    # --- Filtros mínimos para sequer considerar um token novo ---
    min_creator_sol_committed: float = float(os.getenv("MIN_CREATOR_SOL_COMMITTED", "0.5"))

    # --- Limite de exposição simultânea ---
    max_concurrent_positions: int = int(os.getenv("MAX_CONCURRENT_POSITIONS", "5"))

    # --- Checagem de segurança do token (mint/freeze authority, concentração) ---
    enable_safety_check: bool = field(default_factory=lambda: _get_bool("ENABLE_SAFETY_CHECK", True))
    max_top_holder_pct: float = float(os.getenv("MAX_TOP_HOLDER_PCT", "20"))
    safety_check_timeout_seconds: float = float(os.getenv("SAFETY_CHECK_TIMEOUT_SECONDS", "3"))

    # --- Alertas (Discord/Telegram) ---
    discord_webhook_url: str = os.getenv("DISCORD_WEBHOOK_URL", "")
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")

    # --- Saída parcial em camadas ---
    # Lista de (patamar_%, % do que resta a vender nesse patamar). Ex:
    # "100:50,300:50" = ao bater +100%, vende metade do que tem; ao bater
    # +300%, vende metade do que sobrou (25% da posição original), deixando
    # o resto correr até stop loss / take profit / timeout.
    partial_take_profit_levels: List[tuple] = field(
        default_factory=lambda: _get_level_pairs("PARTIAL_TAKE_PROFIT_LEVELS", [(100.0, 50.0), (300.0, 50.0)])
    )


settings = Settings()
