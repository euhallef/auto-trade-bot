"""
Estruturas de dados centrais usadas em todo o projeto.
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class TokenCreated:
    """Evento de criação de um novo token na pump.fun."""
    mint: str
    name: str
    symbol: str
    creator: str
    created_at: float  # unix timestamp
    initial_sol_in_curve: float
    initial_tokens_in_curve: float
    initial_market_cap_sol: float
    uri: Optional[str] = None


@dataclass
class Trade:
    """Evento de compra ou venda em um token."""
    signature: str
    mint: str
    trader: str
    tx_type: str  # "buy" ou "sell"
    sol_amount: float
    token_amount: float
    market_cap_sol: float
    timestamp: float


@dataclass
class WalletScore:
    """Pontuação agregada de uma wallet com base no histórico observado."""
    wallet: str
    tokens_touched: int
    early_entries: int          # quantas vezes entrou entre os primeiros N compradores
    tokens_profitable: int          # tokens em que o PnL (realizado + marcado a mercado) foi positivo
    tokens_unprofitable: int        # tokens em que o PnL foi negativo
    total_pnl_sol: float            # soma do PnL estimado (realizado + posições ainda abertas a preço atual)
    avg_entry_market_cap_sol: float
    reputation_score: float     # -1.0 (péssimo sinal) a 1.0 (ótimo sinal), baseado em win rate por PnL


@dataclass
class WalletPnl:
    """PnL estimado de uma wallet em um único mint, a partir dos trades observados."""
    wallet: str
    mint: str
    sol_spent: float
    sol_received: float
    realized_pnl_sol: float         # sol_received - sol_spent (fluxo de caixa líquido)
    remaining_tokens: float         # tokens ainda não vendidos (pelo que foi observado)
    unrealized_value_sol: float     # valor estimado do que resta, ao último preço implícito visto
    total_pnl_sol: float            # realized_pnl_sol + unrealized_value_sol


@dataclass
class ThresholdStat:
    """Resultado do backtest para um patamar de valorização (ex: +200%)."""
    threshold_pct: float
    sample_size: int
    pct_that_kept_rising: float      # % dos casos em que subiu mais depois desse patamar
    pct_that_dropped_20pct: float    # % dos casos em que caiu >=20% do pico após esse patamar
    median_extra_upside_pct: float
    median_drawdown_after_pct: float
