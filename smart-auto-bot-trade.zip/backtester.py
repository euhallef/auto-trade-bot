"""
Este é o módulo que responde à pergunta original: "a partir de quanto %
de alta fica arriscado continuar no token?"

Em vez de assumir um número (ex: "200%"), ele CALCULA empiricamente, a
partir do histórico coletado, o que de fato aconteceu depois que um token
cruzou cada patamar de valorização.

ATENÇÃO METODOLÓGICA (leia antes de confiar nos números):
- Isso é só tão bom quanto os dados coletados. Rodando poucos dias, a
  amostra é pequena e o resultado é ruído, não sinal.
- Sofre viés de sobrevivência: tokens que morreram (foram a zero em
  segundos, sem trades suficientes) tendem a ficar sub-representados
  se sua janela de coleta perdeu o início deles.
- Padrões observados no passado podem não persistir — memecoin é um
  mercado adversarial que se adapta.
"""
import statistics
from typing import List

from config import settings
from database import get_all_tokens, get_trades_for_mint
from models import ThresholdStat


def _build_pct_series(trades: List, initial_cap: float) -> List[tuple]:
    """Retorna lista de (timestamp, pct_change_desde_criacao) ordenada no tempo."""
    if initial_cap <= 0:
        return []
    series = []
    for t in trades:
        cap = t["market_cap_sol"] or 0
        pct = (cap - initial_cap) / initial_cap * 100.0
        series.append((t["timestamp"], pct))
    return series


def analyze_threshold(threshold_pct: float) -> ThresholdStat:
    """
    Para um patamar (ex: 200%), encontra todos os tokens que o
    ultrapassaram e mede o que aconteceu na janela seguinte
    (settings.forward_window_seconds): subiu mais, ou caiu >=20% do pico?

    Trades depois de `graduated_at` são descartados: uma vez que o token
    migra da bonding curve para um AMM (Raydium/PumpSwap), a dinâmica de
    preço muda de regime, e misturar os dois no mesmo backtest distorceria
    os patamares calculados.
    """
    extra_upsides = []
    drawdowns = []
    kept_rising = 0
    dropped_20 = 0
    sample_size = 0

    for token in get_all_tokens():
        initial_cap = token["initial_market_cap_sol"] or 0
        trades = get_trades_for_mint(token["mint"])
        graduated_at = token["graduated_at"]
        if graduated_at:
            trades = [t for t in trades if t["timestamp"] < graduated_at]
        series = _build_pct_series(trades, initial_cap)
        if not series:
            continue

        # acha o primeiro momento em que cruzou o patamar
        cross_idx = None
        for i, (_, pct) in enumerate(series):
            if pct >= threshold_pct:
                cross_idx = i
                break
        if cross_idx is None:
            continue

        cross_time, cross_pct = series[cross_idx]
        window_end = cross_time + settings.forward_window_seconds
        forward = [pct for ts, pct in series[cross_idx:] if ts <= window_end]
        if len(forward) < 2:
            continue

        sample_size += 1
        peak = max(forward)
        trough_after_peak = min(forward[forward.index(peak):]) if peak in forward else min(forward)

        extra_upside = peak - cross_pct
        drawdown_from_peak = peak - trough_after_peak

        extra_upsides.append(extra_upside)
        drawdowns.append(drawdown_from_peak)

        if peak > cross_pct * 1.05:
            kept_rising += 1
        if drawdown_from_peak >= 20:
            dropped_20 += 1

    if sample_size == 0:
        return ThresholdStat(threshold_pct, 0, 0.0, 0.0, 0.0, 0.0)

    return ThresholdStat(
        threshold_pct=threshold_pct,
        sample_size=sample_size,
        pct_that_kept_rising=round(100 * kept_rising / sample_size, 1),
        pct_that_dropped_20pct=round(100 * dropped_20 / sample_size, 1),
        median_extra_upside_pct=round(statistics.median(extra_upsides), 1),
        median_drawdown_after_pct=round(statistics.median(drawdowns), 1),
    )


def run_full_backtest() -> List[ThresholdStat]:
    """Roda a análise para todos os patamares configurados em settings.thresholds_pct."""
    return [analyze_threshold(p) for p in settings.thresholds_pct]


def print_report(stats: List[ThresholdStat]) -> None:
    print(f"{'Patamar':>10} {'Amostra':>8} {'Subiu +5%':>10} {'Caiu>=20%':>10} "
          f"{'Upside med.':>12} {'Drawdown med.':>14}")
    for s in stats:
        print(f"{s.threshold_pct:>9.0f}% {s.sample_size:>8} "
              f"{s.pct_that_kept_rising:>9.1f}% {s.pct_that_dropped_20pct:>9.1f}% "
              f"{s.median_extra_upside_pct:>11.1f}% {s.median_drawdown_after_pct:>13.1f}%")

    if stats and stats[0].sample_size < 50:
        print("\n[AVISO] Amostra pequena (<50 tokens no maior patamar analisado).")
        print("Rode o coletor por mais tempo antes de confiar nesses números.")


if __name__ == "__main__":
    from database import init_db
    init_db()
    results = run_full_backtest()
    print_report(results)
