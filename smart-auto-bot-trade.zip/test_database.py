import sqlite3

import database


def test_schema_has_expected_tables(db):
    with database.get_conn() as conn:
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"tokens", "trades", "bot_positions", "position_exits"} <= tables


def test_migration_adds_columns_without_losing_data(db):
    """Simula um banco no schema antigo (sem as colunas novas) e confere que
    init_db() migra sem apagar os dados existentes."""
    with database.get_conn() as conn:
        conn.execute("DROP TABLE bot_positions")
        conn.execute("""CREATE TABLE bot_positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT NOT NULL,
            entry_time REAL NOT NULL, entry_market_cap_sol REAL NOT NULL,
            entry_sol_amount REAL NOT NULL, exit_time REAL, exit_market_cap_sol REAL,
            exit_reason TEXT, dry_run INTEGER NOT NULL DEFAULT 1)""")
        conn.execute("INSERT INTO bot_positions (mint, entry_time, entry_market_cap_sol, "
                     "entry_sol_amount, dry_run) VALUES ('MINTOLD', 1.0, 30.0, 0.05, 1)")

    database.init_db()  # deve migrar em cima do banco "antigo" simulado acima

    positions = database.get_open_positions()
    assert len(positions) == 1
    assert positions[0]["mint"] == "MINTOLD"
    assert positions[0]["remaining_pct"] == 100.0
    assert positions[0]["hit_levels"] == ""


def test_position_full_exit_lifecycle(db):
    pos_id = database.record_position_entry("MINT1", 30.0, 0.05, dry_run=True)
    assert len(database.get_open_positions()) == 1

    database.record_position_exit(pos_id, 60.0, "take profit")

    assert len(database.get_open_positions()) == 0
    with database.get_conn() as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM bot_positions WHERE id = ?", (pos_id,)).fetchone()
        assert row["exit_reason"] == "take profit"
        assert row["remaining_pct"] == 0


def test_partial_exit_reduces_remaining_and_records_history(db):
    pos_id = database.record_position_entry("MINT2", 30.0, 0.05, dry_run=True)

    remaining = database.record_partial_exit(pos_id, 50.0, "L100", 60.0, "patamar 1")
    assert remaining == 50.0
    assert len(database.get_open_positions()) == 1  # ainda aberta

    remaining2 = database.record_partial_exit(pos_id, 50.0, "L300", 120.0, "patamar 2")
    assert remaining2 == 25.0

    with database.get_conn() as conn:
        exits = conn.execute("SELECT * FROM position_exits WHERE position_id = ?", (pos_id,)).fetchall()
        assert len(exits) == 2


def test_max_concurrent_positions_query(db):
    for i in range(3):
        database.record_position_entry(f"MINT{i}", 30.0, 0.05, dry_run=True)
    assert len(database.get_open_positions()) == 3


def test_graduation_marking(db):
    from models import TokenCreated
    database.insert_token(TokenCreated("MINTG", "Grad", "GRD", "Creator1", 1.0, 1, 900000000, 30.0))
    assert database.get_token("MINTG")["graduated_at"] is None

    database.mark_token_graduated("MINTG", graduated_at=123.0)
    assert database.get_token("MINTG")["graduated_at"] == 123.0

    # não deve sobrescrever se já estava marcado
    database.mark_token_graduated("MINTG", graduated_at=999.0)
    assert database.get_token("MINTG")["graduated_at"] == 123.0
