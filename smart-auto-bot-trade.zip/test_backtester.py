import random
import time

from database import insert_token, insert_trade, mark_token_graduated
from models import TokenCreated, Trade
from backtester import analyze_threshold, run_full_backtest


def _build_rug_scenario(db, n_tokens=30, seed=7):
    """Tokens que sobem rápido e desabam logo depois (padrão rug clássico)."""
    rnd = random.Random(seed)
    base_t = time.time() - 100000
    for i in range(n_tokens):
        mint = f"RUG{i}"
        created_at = base_t + i * 500
        insert_token(TokenCreated(mint, mint, mint[:4], "CreatorRug", created_at, 1, 900000000, 30.0))
        cap = 30.0
        ts = created_at
        peak_mult = rnd.uniform(4, 10)
        n_trades = rnd.randint(20, 40)
        for j in range(n_trades):
            ts += rnd.uniform(5, 30)
            progress = j / n_trades
            mult = 1 + peak_mult * min(progress * 3, 1) if progress < 0.4 else max(0.2, peak_mult * (1 - progress))
            cap = 30.0 * mult
            insert_trade(Trade(f"{mint}-{j}", mint, f"trader{j}", "buy" if j % 2 == 0 else "sell",
                                0.5, 500, cap, ts))


def test_higher_thresholds_show_more_drawdown_in_rug_scenario(db):
    _build_rug_scenario(db)
    low = analyze_threshold(50)
    high = analyze_threshold(500)

    assert low.sample_size > 0
    assert high.sample_size > 0
    # no cenário de rug, quem entra tarde (depois de +500%) deveria ver
    # proporcionalmente mais casos de queda forte do que quem entra em +50%
    assert high.pct_that_dropped_20pct >= low.pct_that_dropped_20pct


def test_threshold_with_no_data_returns_empty_stat(db):
    stat = analyze_threshold(9999)
    assert stat.sample_size == 0


def test_run_full_backtest_returns_all_configured_thresholds(db):
    _build_rug_scenario(db, n_tokens=10)
    from config import settings
    stats = run_full_backtest()
    assert len(stats) == len(settings.thresholds_pct)


def test_graduated_trades_excluded_from_analysis(db):
    """
    Trades registrados DEPOIS da graduação não devem contar no backtest
    baseado em bonding curve — misturar os dois regimes de preço distorce
    os patamares calculados.
    """
    t0 = time.time() - 1000
    insert_token(TokenCreated("MINTGRAD", "Grad", "GRD", "Creator1", t0, 1, 900000000, 30.0))
    insert_trade(Trade("g1", "MINTGRAD", "trader1", "buy", 1.0, 100, 60, t0 + 10))    # +100%, antes de graduar
    insert_trade(Trade("g1b", "MINTGRAD", "trader1", "buy", 1.0, 100, 65, t0 + 15))   # ainda antes de graduar
    graduation_time = t0 + 20
    mark_token_graduated("MINTGRAD", graduated_at=graduation_time)
    # trade pós-graduação com preço completamente diferente de regime (não deveria contar)
    insert_trade(Trade("g2", "MINTGRAD", "trader1", "sell", 50.0, 100, 5000, t0 + 30))

    stat = analyze_threshold(50)
    # amostra existe (os trades pré-graduação cruzaram +50%), mas o valor
    # absurdo pós-graduação (5000) não deve ter entrado na janela analisada
    assert stat.sample_size >= 1
    assert stat.median_extra_upside_pct < 1000  # se o trade pós-migração tivesse entrado, isso explodiria
