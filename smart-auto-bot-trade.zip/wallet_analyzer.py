"""
Analisa wallets com base no histórico registrado localmente:

1. Quais wallets aparecem como compradores "early" (entre os primeiros N)
   em vários tokens diferentes -> possível cluster de smart money OU de
   insiders/bundlers do próprio criador (os dois padrões parecem iguais
   de fora — ver README sobre essa ambiguidade).

2. Reputação de criadores: dos tokens anteriores que essa wallet criou,
   quantos mantiveram valor vs. quantos "morreram" logo após o lançamento
   (sinal de rug/wash trading).

Importante: isso mede correlação histórica, não causalidade. Uma wallet
"boa" no passado pode ser só sorte em amostra pequena — por isso o
min_tokens_for_reputation em config.py.
"""
from collections import defaultdict
from typing import Dict, List

from config import settings
from database import get_all_tokens, get_trades_for_mint, get_tokens_by_creator, get_trades_for_wallet
from models import WalletScore, WalletPnl


def _price_ratio_at_end(trades: List) -> float:
    """Razão entre o último market cap observado e o primeiro (usado só para reputação de criador)."""
    if len(trades) < 2:
        return 1.0
    first = trades[0]["market_cap_sol"] or 1e-9
    last = trades[-1]["market_cap_sol"] or 1e-9
    return last / first


def compute_mint_pnl_for_wallet(wallet: str, mint: str, all_trades: List = None) -> WalletPnl:
    """
    Reconstrói o fluxo de caixa de uma wallet num token específico:
    quanto SOL ela gastou comprando, quanto recebeu vendendo, e quanto
    ainda resta em tokens não vendidos (avaliado ao último preço
    implícito observado no mercado — não é uma garantia de que ela
    conseguiria vender a esse preço, é só uma marcação a mercado).
    """
    trades = all_trades if all_trades is not None else get_trades_for_mint(mint)
    wallet_trades = [t for t in trades if t["trader"] == wallet]

    sol_spent = sum((t["sol_amount"] or 0) for t in wallet_trades if t["tx_type"] == "buy")
    sol_received = sum((t["sol_amount"] or 0) for t in wallet_trades if t["tx_type"] == "sell")
    tokens_bought = sum((t["token_amount"] or 0) for t in wallet_trades if t["tx_type"] == "buy")
    tokens_sold = sum((t["token_amount"] or 0) for t in wallet_trades if t["tx_type"] == "sell")
    remaining = max(tokens_bought - tokens_sold, 0.0)
    realized = sol_received - sol_spent

    unrealized = 0.0
    if remaining > 0 and trades:
        last_trade = trades[-1]  # trade mais recente DO TOKEN, não só da wallet -> proxy do preço atual
        if last_trade["token_amount"]:
            implied_unit_price = (last_trade["sol_amount"] or 0) / last_trade["token_amount"]
            unrealized = remaining * implied_unit_price

    return WalletPnl(
        wallet=wallet, mint=mint, sol_spent=round(sol_spent, 6), sol_received=round(sol_received, 6),
        realized_pnl_sol=round(realized, 6), remaining_tokens=remaining,
        unrealized_value_sol=round(unrealized, 6), total_pnl_sol=round(realized + unrealized, 6),
    )


def compute_wallet_pnl(wallet: str) -> List[WalletPnl]:
    """PnL estimado da wallet em CADA token que ela já tocou (não só early buys)."""
    trades = get_trades_for_wallet(wallet)
    mints = sorted(set(t["mint"] for t in trades))
    return [compute_mint_pnl_for_wallet(wallet, mint) for mint in mints]


def build_early_buyer_index() -> Dict[str, List[str]]:
    """Retorna {wallet: [mints em que ela comprou entre os primeiros N]}."""
    index: Dict[str, List[str]] = defaultdict(list)
    for token in get_all_tokens():
        trades = get_trades_for_mint(token["mint"])
        buys = [t for t in trades if t["tx_type"] == "buy"]
        early = buys[: settings.early_buyer_window]
        for t in early:
            index[t["trader"]].append(token["mint"])
    return index


def score_wallet(wallet: str) -> WalletScore:
    """
    Calcula reputação de uma wallet com base no PnL real estimado
    (não só se o preço do token subiu depois que ela entrou — isso importa
    porque uma wallet pode vender cedo com lucro pequeno mesmo num token
    que depois despenca, e isso é um resultado BOM pra ela, não ruim).
    """
    early_index = build_early_buyer_index()
    mints = early_index.get(wallet, [])

    profitable, unprofitable = 0, 0
    entry_caps = []
    total_pnl = 0.0

    for mint in mints:
        trades = get_trades_for_mint(mint)
        wallet_trades = [t for t in trades if t["trader"] == wallet]
        if not wallet_trades:
            continue
        entry_caps.append(wallet_trades[0]["market_cap_sol"] or 0)

        pnl = compute_mint_pnl_for_wallet(wallet, mint, all_trades=trades)
        total_pnl += pnl.total_pnl_sol
        if pnl.total_pnl_sol > 0:
            profitable += 1
        elif pnl.total_pnl_sol < 0:
            unprofitable += 1

    total = max(len(mints), 1)
    reputation = (profitable - unprofitable) / total

    return WalletScore(
        wallet=wallet,
        tokens_touched=len(mints),
        early_entries=len(mints),
        tokens_profitable=profitable,
        tokens_unprofitable=unprofitable,
        total_pnl_sol=round(total_pnl, 4),
        avg_entry_market_cap_sol=sum(entry_caps) / len(entry_caps) if entry_caps else 0.0,
        reputation_score=round(reputation, 3),
    )


def rank_wallets(min_tokens: int = None) -> List[WalletScore]:
    """Rankeia todas as wallets conhecidas por reputação (maior primeiro)."""
    min_tokens = min_tokens or settings.min_tokens_for_reputation
    early_index = build_early_buyer_index()
    scores = []
    for wallet, mints in early_index.items():
        if len(mints) < min_tokens:
            continue
        scores.append(score_wallet(wallet))
    return sorted(scores, key=lambda s: s.reputation_score, reverse=True)


def creator_reputation(creator: str) -> float:
    """
    Reputação do criador com base nos tokens anteriores que ele já lançou.
    Retorna score de -1 (sempre rugou) a 1 (sempre sustentou valor).
    Retorna 0.0 (neutro) se não há histórico suficiente.
    """
    past_tokens = get_tokens_by_creator(creator)
    if len(past_tokens) < 2:  # o token atual + pelo menos 1 anterior
        return 0.0

    outcomes = []
    for token in past_tokens[:-1]:  # exclui o token mais recente (ainda em andamento)
        trades = get_trades_for_mint(token["mint"])
        if len(trades) < 2:
            continue
        ratio = _price_ratio_at_end(trades)
        outcomes.append(1 if ratio >= 1.0 else -1)

    if not outcomes:
        return 0.0
    return round(sum(outcomes) / len(outcomes), 3)


def find_wallet_clusters(min_shared_tokens: int = 3) -> Dict[frozenset, List[str]]:
    """
    Agrupamento simples: pares de wallets que aparecem como early buyers
    nos MESMOS tokens repetidamente. Isso é o sinal mais forte de que são
    controladas pela mesma pessoa/grupo (bundle), e não "smart money"
    independente. Trate esses clusters com desconfiança, não como sinal de compra.
    """
    early_index = build_early_buyer_index()
    mint_to_wallets: Dict[str, List[str]] = defaultdict(list)
    for wallet, mints in early_index.items():
        for m in mints:
            mint_to_wallets[m].append(wallet)

    pair_counts: Dict[frozenset, int] = defaultdict(int)
    for mint, wallets in mint_to_wallets.items():
        wallets = list(set(wallets))
        for i in range(len(wallets)):
            for j in range(i + 1, len(wallets)):
                pair_counts[frozenset((wallets[i], wallets[j]))] += 1

    clusters = {pair: count for pair, count in pair_counts.items() if count >= min_shared_tokens}
    return {pair: list(pair) for pair in clusters}
