# Deploy — rodando 24/7

Duas rotas, escolha uma. **systemd** é mais simples de debugar num VPS
comum; **Docker** é melhor se você já usa containers ou quer isolar
dependências do sistema. As duas têm auto-restart em caso de crash e
sobem sozinhas se o servidor reiniciar.

Em ambos os casos: comece rodando com `DRY_RUN=true` por um bom tempo
(ver README.md) antes de sequer considerar colocar uma chave privada real
no `.env` do servidor.

## Escolhendo o servidor

- Qualquer VPS pequeno resolve para a fase de coleta/análise (1 vCPU,
  1-2GB RAM já sobra) — Hetzner, DigitalOcean, Contabo, Vultr são opções
  comuns e baratas.
- Se um dia for para execução real, latência até a RPC importa mais que
  a máquina em si: prefira uma região próxima do seu provedor de RPC
  (Helius/QuickNode/Triton normalmente têm infra na costa leste dos EUA).
  Isso está fora do escopo do bot em si — é sobre onde ele roda.
- Evite rodar isso num computador doméstico/Wi-Fi: qualquer queda de
  internet ou reinício derruba o bot sem alertar direito.

## Opção A — systemd (recomendado para começar)

1. **Crie um usuário dedicado** (nunca rode como root):
   ```
   sudo useradd -r -m -d /opt/pumpfun-bot -s /usr/sbin/nologin pumpfunbot
   ```

2. **Copie o projeto para o servidor** (via `git clone`, `scp`, `rsync` —
   o que preferir) em `/opt/pumpfun-bot`, e ajuste a posse:
   ```
   sudo chown -R pumpfunbot:pumpfunbot /opt/pumpfun-bot
   ```

3. **Crie o ambiente virtual e instale as dependências**:
   ```
   cd /opt/pumpfun-bot
   sudo -u pumpfunbot python3 -m venv venv
   sudo -u pumpfunbot ./venv/bin/pip install -r requirements.txt
   ```

4. **Configure o `.env`** a partir do `.env.example`, preenchendo o que
   for usar, e **restrinja a permissão** (ele pode conter uma chave
   privada de wallet):
   ```
   sudo -u pumpfunbot cp .env.example .env
   sudo -u pumpfunbot nano .env
   sudo chmod 600 /opt/pumpfun-bot/.env
   ```

5. **Instale o serviço**:
   ```
   sudo cp deploy/pumpfun-bot.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable --now pumpfun-bot
   ```

6. **Acompanhe os logs**:
   ```
   journalctl -u pumpfun-bot -f
   ```

7. **Depois de atualizar o código** (`git pull` ou copiar arquivos novos):
   ```
   sudo systemctl restart pumpfun-bot
   ```

Comandos úteis do dia a dia: `systemctl status pumpfun-bot`,
`systemctl stop pumpfun-bot`, `journalctl -u pumpfun-bot --since "1 hour ago"`.

## Opção B — Docker

1. **Instale Docker e o plugin compose** no servidor (`docker --version`
   e `docker compose version` devem funcionar).

2. **Configure o `.env`** a partir do `.env.example` (fica na raiz do
   projeto, ao lado do `docker-compose.yml`):
   ```
   cp .env.example .env
   nano .env
   chmod 600 .env
   ```

3. **Suba o container**:
   ```
   docker compose up -d --build
   ```
   Isso cria a pasta `./data/` no host — é lá que o SQLite fica de
   verdade, sobrevivendo a rebuilds do container.

4. **Acompanhe os logs**:
   ```
   docker compose logs -f
   ```

5. **Depois de atualizar o código**:
   ```
   git pull
   docker compose up -d --build
   ```

Comandos úteis: `docker compose ps`, `docker compose stop`,
`docker compose down` (para e remove o container, mas `./data/` continua
no host).

## Segurança operacional (vale para as duas rotas)

- **Firewall**: libere só o necessário (`ufw allow OpenSSH && ufw enable`
  é um bom começo — o bot não precisa de nenhuma porta de entrada, só
  saída).
- **Nunca versione o `.env`** — confirme que `.gitignore` do seu
  repositório inclui `.env` antes de fazer `git push` de qualquer coisa.
- **Backup do `.env` e do banco** em algum lugar fora do servidor
  (ex: um gerenciador de segredos, ou pelo menos uma cópia criptografada
  local) — se o servidor morrer, você não quer perder o histórico
  coletado nem precisar recriar a wallet.
- **HEARTBEAT_INTERVAL_HOURS** (no `.env`) manda um alerta periódico
  confirmando que o processo está vivo — configure um webhook do Discord
  ou bot do Telegram (ver README.md) pra realmente receber isso; sem
  webhook configurado, o heartbeat só vai pro log local, o que não ajuda
  muito num servidor que você não está olhando.
