# pumpfun-bot

Bot de análise e (opcionalmente) execução automática para tokens novos na
pump.fun: monitora criações, avalia reputação de criadores/holders
recorrentes, calcula estatisticamente patamares de risco de valorização,
e decide entrada/saída com regras de gestão de risco.

## Leia isto antes de rodar qualquer coisa

- **Isto não é uma máquina de lucro garantido.** É um sistema de coleta
  de dados + estatística histórica + regras de risco. Memecoin na
  pump.fun é, na maioria dos casos, um jogo de soma negativa para quem
  não é o criador/insider. Nenhum backtest daqui prevê o futuro.
- **"Wallets que quase sempre lucram" e "insiders/bundlers do criador"
  produzem o mesmo padrão de fora.** O módulo `wallet_analyzer.py`
  encontra correlação (wallets que entraram cedo em tokens que subiram),
  não a causa. Pode ser smart money genuíno ou pode ser a própria equipe
  do token comprando com wallets alternativas antes de "puxar" o preço.
  Trate o score como um filtro de risco, não como sinal de confiança.
- **Todo capital usado deve ser capital que você aceita perder 100%.**
  O `STOP_LOSS_PCT` no `.env` não garante que você vai sair a esse preço:
  em tokens ilíquidos, a próxima transação disponível pode estar bem
  abaixo do stop configurado (slippage).
- **`DRY_RUN=true` é o padrão e deve continuar assim** até você ter
  rodado o bot tempo suficiente para confiar no comportamento dele — ele
  ainda decide e loga tudo, só não envia transações reais.

## Arquitetura

```
data_collector.py  -> conecta no websocket público da PumpPortal,
                       grava tokens criados e trades no SQLite
wallet_analyzer.py -> calcula reputação de criadores e de wallets
                       "early buyer" recorrentes, a partir do histórico
                       já coletado
backtester.py      -> para cada patamar de valorização (50%, 100%, 200%...),
                       calcula empiricamente o que aconteceu depois
                       (subiu mais? caiu >=20% do pico?) nos tokens já
                       observados
token_safety.py    -> checagem pré-compra via RPC direta: mint/freeze
                       authority revogadas? concentração de supply fora
                       da bonding curve dentro do limite?
strategy.py        -> combina os sinais acima + stop-loss/take-profit/
                       tempo máximo de hold em uma decisão BUY/HOLD/SELL
executor.py        -> constrói, assina localmente e envia a transação via
                       PumpPortal + sua própria RPC (só quando DRY_RUN=false),
                       incluindo vendas parciais em camadas
alerts.py          -> notifica Discord/Telegram a cada compra, venda,
                       veto de segurança e erro (opcional, mas recomendado
                       pra rodar sem ficar colado no log)
main.py            -> orquestra tudo em tempo real: compra, monitora
                       posições (incluindo saída parcial), e monitora
                       migração pra AMM, aplicando MAX_CONCURRENT_POSITIONS
                       antes de qualquer compra
database.py        -> camada SQLite (com migração de schema automática)
maintenance.py     -> arquivamento/limpeza de trades antigos (rodar via cron)
models.py          -> estruturas de dados
config.py          -> todas as configurações via .env
tests/             -> suite pytest cobrindo os módulos de análise e decisão
```

## Setup

1. `pip install -r requirements.txt`
2. `cp .env.example .env` e preencha:
   - Para só coletar dados e analisar (recomendado no início): não
     precisa preencher `SOLANA_RPC_URL` nem `SOLANA_PRIVATE_KEY`.
   - Para execução real, mais adiante: crie uma API key em
     [pumpportal.fun](https://pumpportal.fun) (a Trading API cobra 0.5%
     por trade), contrate uma RPC dedicada (Helius, QuickNode ou
     similar — RPCs públicas são lentas demais para esse mercado), e
     gere uma wallet **nova e dedicada** só para o bot.
3. `python main.py`

Isso já roda localmente na sua máquina, útil para testar. Para deixar
rodando 24/7 num servidor (com auto-restart, sobrevivendo a reboot), veja
**[DEPLOY.md](DEPLOY.md)** — cobre tanto systemd quanto Docker.

## Como usar de forma responsável (nessa ordem)

1. **Rode só a coleta por vários dias** (`data_collector.py` já roda
   dentro do `main.py`). Sem isso, `backtester.py` não tem amostra.
2. **Rode `python backtester.py`** para ver os patamares calculados a
   partir dos seus próprios dados — não confie em números "assumidos"
   de fora, gere os seus.
3. **Rode `python -c "from wallet_analyzer import rank_wallets; print(rank_wallets())"`**
   para ver quais wallets/criadores aparecem com reputação historicamente
   melhor — e desconfie de qualquer uma que apareça em clusters
   (`find_wallet_clusters()`), sinal de possível bundle/insider.
4. **Deixe `main.py` rodando em DRY_RUN por um bom tempo** e audite a
   tabela `bot_positions` do SQLite: o que o bot teria comprado, quando
   teria vendido, e qual teria sido o resultado.
5. **Só depois disso**, e só com capital que você aceita perder por
   completo, considere `DRY_RUN=false`.

## Recursos de segurança adicionados

- **`MAX_CONCURRENT_POSITIONS`** — o bot nunca abre mais que essa
  quantidade de posições ao mesmo tempo, mesmo que vários tokens bons
  apareçam juntos num pico de criação.
- **Checagem pré-compra (`token_safety.py`)** — antes de qualquer compra,
  o bot consulta a RPC diretamente (não depende da PumpPortal pra isso) e
  veta a compra se: a mint authority não foi revogada (criador pode
  mintar mais do nada), a freeze authority não foi revogada (criador
  pode congelar contas, impedindo venda — honeypot clássico), ou uma
  wallet fora da própria bonding curve concentra mais que
  `MAX_TOP_HOLDER_PCT`% do supply. **Isso exige `SOLANA_RPC_URL`
  configurada** — sem ela, a checagem é pulada (fica só rodando
  coleta/análise sem bloquear nada).
- **Alertas (`alerts.py`)** — cada compra, venda, veto de segurança e
  erro de execução dispara uma notificação (Discord webhook e/ou bot do
  Telegram, configuráveis no `.env`; se nenhum estiver configurado, só
  vai pro log local). Erros de venda em modo real são marcados como
  "ação manual pode ser necessária" — se o bot não conseguir vender
  automaticamente, você precisa saber na hora, não no dia seguinte.
- **Heartbeat** — a cada `HEARTBEAT_INTERVAL_HOURS` (padrão 6h), o bot
  manda um alerta só confirmando que está vivo e quantas posições tem
  abertas. Se parar de chegar, algo travou.
- **PnL real por wallet** (`wallet_analyzer.py`) — reconstrói o fluxo de
  caixa de cada wallet por token (`compute_wallet_pnl`), em vez de só
  olhar se o preço do token subiu ou caiu no fim.
- **Detecção de migração pra AMM** (`token_safety.py`) — lê a conta
  on-chain da bonding curve para saber quando um token "graduou" pra
  Raydium/PumpSwap, e o backtest exclui dados pós-migração da análise.
- **Saída parcial em camadas** (`PARTIAL_TAKE_PROFIT_LEVELS`) — realiza
  lucro aos poucos conforme o preço sobe, em vez de tudo-ou-nada.
- **`maintenance.py`** — arquiva trades antigos pra manter o SQLite
  enxuto (rode via cron: `python maintenance.py --days 30`).
- **`tests/`** — suite pytest cobrindo banco, análise e estratégia
  (`pytest`, precisa de `pip install -r requirements.txt` antes).

## Limitações conhecidas

- O feed da PumpPortal só entrega eventos a partir do momento em que
  você conecta — não há histórico retroativo nele. Para uma base maior
  sem esperar dias, você precisaria complementar com um indexador
  histórico (Bitquery, Helius, Dune Analytics), o que não está
  implementado aqui.
- `wallet_analyzer.py` mede resultado via variação de `market_cap_sol`
  nos trades observados, não PnL realizado exato por wallet (isso
  exigiria reconstruir todas as posições de cada wallet, o que é
  possível mas fica para uma iteração futura).
- Não há proteção contra "honeypots" (tokens que tecnicamente permitem
  compra mas bloqueiam venda) além do que a própria PumpPortal já filtra.
- Nenhum número de "taxa de acerto" está embutido no código de propósito
  — ele é gerado pelo seu próprio backtest, com seus próprios dados, e
  vai mudar conforme o mercado muda.
